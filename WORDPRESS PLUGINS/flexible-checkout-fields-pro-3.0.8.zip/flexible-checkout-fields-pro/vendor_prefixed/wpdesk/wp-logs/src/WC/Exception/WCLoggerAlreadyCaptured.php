<?php

namespace FCFProVendor\WPDesk\Logger\WC\Exception;

class WCLoggerAlreadyCaptured extends \RuntimeException
{
}
