<?php

class WPML_Media_Exception extends Exception {
}
